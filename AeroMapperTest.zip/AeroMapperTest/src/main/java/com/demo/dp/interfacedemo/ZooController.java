package com.demo.dp.interfacedemo;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@AllArgsConstructor
public class ZooController {
    ZooService zooService;

    @GetMapping("/getzoo/{id}")
    public List<Animals> getAnimalFromZoo(@PathVariable("id") int id) {
        return zooService.getAnimalFromZoo(id).getAnimalsList();
    }

    @PostMapping("/setzoo")
    public void addTrain() {
        zooService.addAnimalsToZoo();
    }


}
