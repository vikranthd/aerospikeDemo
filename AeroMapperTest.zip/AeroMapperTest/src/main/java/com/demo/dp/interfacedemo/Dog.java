package com.demo.dp.interfacedemo;

import com.aerospike.mapper.annotations.AerospikeRecord;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@AerospikeRecord(namespace="test", set="dog")
public class Dog implements Animals{
    String breed;
//    public String getDog(){
//        return breed;
//    }
//
//    public void setDog(String breed){
//        this.breed = breed;
//    }

}
