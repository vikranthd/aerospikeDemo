package com.demo.dp.interfacedemo;

import com.aerospike.mapper.annotations.AerospikeRecord;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@AerospikeRecord(namespace = "test",set = "cat")
public class Cat implements Animals{
    String breed;
    String lifeSpan;

//    public String getCatBreed(){
//        return breed;
//    }
//
//    public String getCatLifeSpan(){
//        return lifeSpan;
//    }
//
//    public void setCatBreed(String breed){
//        this.breed = breed;
//    }
//
//    public void setCatLifeSpan(String lifeSpan){
//        this.lifeSpan = lifeSpan;
//    }
}
