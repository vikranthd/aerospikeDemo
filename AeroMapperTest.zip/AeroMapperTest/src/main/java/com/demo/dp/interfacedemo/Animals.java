package com.demo.dp.interfacedemo;


public interface Animals {
}
