package com.demo.dp.interfacedemo;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.policy.ReadModeAP;
import com.aerospike.mapper.tools.AeroMapper;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "aerospike")
public class DefineClientMapper {
    private String host;
    private int port;
    AerospikeClient aerospikeClient;

    @Bean
    public AerospikeClient getAerospikeClient(){
       aerospikeClient  = new AerospikeClient(host,port);
       return aerospikeClient;
    }
    @Bean
    public AeroMapper getAeroMapper() {
        aerospikeClient = getAerospikeClient();
        AeroMapper aeroMapper = new AeroMapper.Builder(aerospikeClient).build();
        aeroMapper.getReadPolicy(AeroMapper.class).readModeAP = ReadModeAP.ONE;
        return aeroMapper;
    }


}
