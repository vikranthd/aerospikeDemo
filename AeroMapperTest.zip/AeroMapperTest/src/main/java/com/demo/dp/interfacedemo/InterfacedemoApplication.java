package com.demo.dp.interfacedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
//@ConfigurationPropertiesScan
public class InterfacedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterfacedemoApplication.class, args);
	}

}
